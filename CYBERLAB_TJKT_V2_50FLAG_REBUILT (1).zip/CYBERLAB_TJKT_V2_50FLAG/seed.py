#!/usr/bin/env python3
import os, pathlib, secrets, base64, codecs, sqlite3, hashlib, json, zipfile, tarfile, io, gzip, struct, socket, urllib.parse
R=pathlib.Path('/opt/cyberlab'); H=pathlib.Path('/home/student'); W=pathlib.Path('/var/www/html'); E=R/'evidence'
for p in [R,E,H/'documents',H/'cases',W/'lab-sqli',W/'lab-xss',W/'archive'] : p.mkdir(parents=True,exist_ok=True)
flags={i:f'TJKT{{F{i:02d}_{secrets.token_hex(9).upper()}}}' for i in range(1,51)}
def put(p,s):
 p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8')
def bput(p,b):
 p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
put(H/'README-MISI.txt','CYBERLAB TJKT V2 - 50 FLAG HUNTER\nCari flag TJKT{...} melalui investigasi terminal. Gunakan cat ~/cases/MISSIONS.txt untuk daftar misi. Tidak perlu internet. Jangan menggunakan sudo.\n')
put(H/'cases/MISSIONS.txt','\n'.join(f'{i:02d}. '+n for i,n in enumerate(['Hidden Welcome','Directory Explorer','File Content Search','Linux User Discovery','System Information','Hidden Dotfile','Symbolic Link','Archive Explorer','Text Filtering','Manual Page Clue','Base64 Message','Hexadecimal Clue','ROT13 Cipher','File Permission Audit','Environment Variables','Process Investigation','Cron Job Discovery','Log Timeline','Backup Recovery','SSH Configuration','Open Port Discovery','HTTP Header Analysis','Robots.txt Trail','Web Source Inspection','Directory Listing','SQLite Investigation','SQL Injection Login','SQL Injection Data Retrieval','XSS Reflection','Weak Password Audit','PCAP HTTP Analysis','DNS Forensics','Authentication Log Investigation','Web Access Log Forensics','File Metadata Analysis','Encoded Archive','Misconfigured Service','Incident Timeline','Suspicious Script Analysis','Evidence Correlation','Multi-Layer Encoding','Database Breach Investigation','Credential Exposure Case','Web Attack Reconstruction','Malicious Cron Investigation','PCAP Exfiltration Analysis','Linux Persistence Forensics','Multi-Service Investigation','Incident Response Report','CYBERLAB Final Mission'],1))+'\n')
put(H/'.welcome_flag',flags[1]);put(H/'documents/maze/a/b/c/finish.txt',flags[2]);put(H/'documents/report.txt','alpha\nbeta\n'+flags[3]+'\n');put(H/'cases/users.txt','training account: analyst\n'+flags[4]);put(H/'cases/system-info.txt','hostname: cyberlab-tjkt\n'+flags[5]);put(H/'documents/.settings',flags[6]);(H/'documents/shortcut').symlink_to('maze/a/b/c/finish.txt') if not (H/'documents/shortcut').exists() else None
put(H/'cases/link-target.txt',flags[7]);(H/'documents/link-clue').symlink_to('../cases/link-target.txt') if not (H/'documents/link-clue').exists() else None
with zipfile.ZipFile(H/'documents/archive.zip','w') as z:z.writestr('readme.txt',flags[8])
put(H/'documents/large.log','\n'.join('INFO routine' for _ in range(100))+'\nFLAG_MARKER '+flags[9]+'\n')
put(H/'cases/manual.txt','Local training manual: find command examples.\n'+flags[10]);put(H/'documents/encoded.b64',base64.b64encode(flags[11].encode()).decode());put(H/'documents/encoded.hex',flags[12].encode().hex());put(H/'documents/encoded.rot13',codecs.encode(flags[13],'rot_13'))
put(H/'documents/public-config.ini','mode=training\n'+flags[14]);os.chmod(H/'documents/public-config.ini',0o666)
put(H/'cases/environment.snapshot','LAB_MODE=offline\nLAB_CLUE='+flags[15]+'\n')
put(H/'cases/process.snapshot','PID COMMAND\n312 /usr/bin/training-agent --note '+flags[16]);put(E/'cron.snapshot','* * * * * student /usr/local/bin/training-check # '+flags[17]);put(E/'events.log','2026-10-01T09:00:00 login success\n2026-10-01T09:01:00 '+flags[18]+'\n')
with zipfile.ZipFile(E/'backup.zip','w') as z:z.writestr('config.old',flags[19]);put(E/'sshd_config.snapshot','PermitRootLogin no\nPasswordAuthentication no\n# audit='+flags[20])
put(E/'ports.txt','127.0.0.1:80 http\n127.0.0.1:8081 training-service\n'+flags[21]);put(W/'headers.php',"<?php header('X-Lab-Clue: "+flags[22]+"'); echo 'Inspect headers'; ?>")
put(W/'robots.txt','User-agent: *\nDisallow: /archive/\n# '+flags[23]);put(W/'source.html','<html><body>Inspect source<!-- '+flags[24]+' --></body></html>');put(W/'archive/index.html','Directory listing simulation: '+flags[25])
db=sqlite3.connect(str(E/'training.sqlite'));db.execute('CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, text TEXT)');db.execute('DELETE FROM notes');db.execute('INSERT INTO notes(text) VALUES(?)',(flags[26],));db.commit();db.close()
# SQL injection uses intentionally unsafe SQLite string concatenation in an isolated training endpoint.
db=sqlite3.connect(str(R/'sqli.sqlite'));db.execute('CREATE TABLE IF NOT EXISTS users(username TEXT,password TEXT,role TEXT)');db.execute('DELETE FROM users');db.execute('INSERT INTO users VALUES(?,?,?)',('analyst',secrets.token_hex(12),'student'));db.execute('CREATE TABLE IF NOT EXISTS vault(secret TEXT)');db.execute('DELETE FROM vault');db.execute('INSERT INTO vault VALUES(?)',(flags[28],));db.commit();db.close();os.chmod(R/'sqli.sqlite',0o644)
put(W/'lab-sqli/index.php', '''<?php
$db=new SQLite3('/opt/cyberlab/sqli.sqlite',SQLITE3_OPEN_READONLY);
$user=$_GET['user']??''; $pass=$_GET['pass']??'';
// Deliberately vulnerable, for isolated offline education only.
$sql="SELECT username FROM users WHERE username='".$user."' AND password='".$pass."'";
$res=@$db->query($sql); $row=$res?$res->fetchArray(SQLITE3_ASSOC):false;
header('Content-Type: text/plain; charset=utf-8');
echo $row ? "Training login accepted. FLAG_LOGIN\n" : "Login failed\n";
?>'''.replace('FLAG_LOGIN',flags[27]))
put(W/'lab-xss/index.php',"<?php $q=$_GET['q']??''; echo '<h2>Search result</h2>'.$q; if(stripos($q,'<script')!==false) echo '<!-- "+flags[29]+" -->'; ?>")
put(E/'password-audit.txt','Training SHA256 password hash (wordlist: classroom): '+hashlib.sha256(b'classroom').hexdigest()+'\nRecovered flag: '+flags[30])
def packet(src,dst,payload,sp=12345,dp=80):
 sb=socket.inet_aton(src);db=socket.inet_aton(dst);tcp=struct.pack('!HHLLBBHHH',sp,dp,1,0,5<<4,0x18,4096,0,0);length=20+len(tcp)+len(payload);ip=struct.pack('!BBHHHBBH4s4s',0x45,0,length,0,0,64,6,0,sb,db);return ip+tcp+payload
def pcap(path,frames):
 data=struct.pack('<IHHIIII',0xa1b2c3d4,2,4,0,0,65535,101)
 for k,f in enumerate(frames):data+=struct.pack('<IIII',1760000000+k,0,len(f),len(f))+f
 bput(path,data)
pcap(E/'http.pcap',[packet('10.10.0.2','10.10.0.3',('GET /?note='+flags[31]+' HTTP/1.1\r\nHost: lab\r\n\r\n').encode())]);put(E/'dns-queries.log','A lab.local\nTXT clue.lab.local '+flags[32]);put(E/'auth.log','Failed password for invalid user admin from 10.0.0.8\n'+flags[33]);put(E/'access.log','10.0.0.8 - - "GET /admin HTTP/1.1" 404\n'+flags[34]);put(E/'metadata.txt','Filename evidence.bin\nAuthor: '+flags[35]);put(E/'layered.txt',base64.b64encode(flags[36].encode().hex().encode()).decode());put(E/'service.conf','listen=127.0.0.1\nexposed_directory=/archive\n'+flags[37]);put(E/'timeline.csv','09:00,failed-login\n09:02,web-request\n09:05,'+flags[38]);put(E/'suspicious.sh.txt','#!/bin/sh\n# DO NOT EXECUTE; static analysis only\n# '+flags[39]);put(E/'correlation.txt','Find shared event ID: EVT-492\nEVT-492 '+flags[40]);put(E/'multi-encoding.txt',base64.b64encode(codecs.encode(flags[41],'rot_13').encode()).decode());put(E/'breach.csv','user,impact\ntraining-user,'+flags[42]);put(E/'credential-exposure.txt','Synthetic training credential exposed in backup\n'+flags[43]);put(E/'web-attack.log','GET /lab-sqli/?user=training HTTP/1.1\n'+flags[44]);put(E/'malicious-cron.snapshot','@reboot student /tmp/simulated-task # '+flags[45]);pcap(E/'exfil.pcap',[packet('10.10.0.4','10.10.0.5',('POST /upload HTTP/1.1\r\nHost: lab\r\n\r\n'+flags[46]).encode(),12345,8080)]);put(E/'persistence.snapshot','training.service enabled\nExecStart=/usr/local/bin/training-agent\n'+flags[47]);put(E/'multi-service.txt','http 80 / ssh disabled / sqlite local\n'+flags[48]);put(E/'incident-report.txt','Root cause: unsafe SQL concatenation\nMitigation: prepared statements\n'+flags[49]);put(E/'final.txt','Final case: correlate incident timeline, network evidence, and SQL training.\n'+flags[50])
# Teacher answer key must leave VM before student distribution.
key=pathlib.Path('/root/CYBERLAB-TEACHER-KEY.txt');put(key,'\n'.join(f'{i:02d} {flags[i]}' for i in range(1,51))+'\n');os.chmod(key,0o600)
put(W/'index.html','<h1>CYBERLAB TJKT</h1><p>Offline lab. Read ~/cases/MISSIONS.txt</p>')
print('Created 50 training flags. Teacher key:',key)
