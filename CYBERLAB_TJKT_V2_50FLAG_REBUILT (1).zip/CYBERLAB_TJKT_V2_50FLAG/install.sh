#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo 'Run: sudo bash install.sh'; exit 1; fi
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 apache2 php libapache2-mod-php php-sqlite3 sqlite3 curl unzip zip nmap tcpdump
if ! id student >/dev/null 2>&1; then adduser --disabled-password --gecos '' student; echo 'Set student password using: sudo passwd student'; fi
if id -nG student | grep -qw sudo; then deluser student sudo; fi
systemctl enable --now apache2
cp "$(dirname "$0")/seed.py" /root/cyberlab-seed.py
python3 /root/cyberlab-seed.py
chown -R student:student /home/student
chmod 755 /opt/cyberlab /opt/cyberlab/evidence
# Prevent PHP access to teacher-only material; Apache is loopback-only.
cat >/etc/apache2/ports.conf <<'EOF'
Listen 127.0.0.1:80
EOF
systemctl restart apache2
printf '\nDONE. Save /root/CYBERLAB-TEACHER-KEY.txt OUTSIDE VM, then remove it and /root/cyberlab-seed.py before exporting OVA.\n'
