# CYBERLAB TJKT V2 — 50 Flag Hunter

Prototype installer for **Ubuntu Server 24.04 LTS**, offline terminal-only, one VM per student. This ZIP is **not an OVA**. 50 random flags are generated at installation time. Some advanced challenges are simplified static evidence investigations, not complete realistic exploitation scenarios.

## Install on a fresh Ubuntu VM

1. VirtualBox: 2 CPU, 2 GB RAM, 25 GB disk, NAT only while installing packages.
2. Create a teacher administrator during Ubuntu installation.
3. Copy this folder into the VM, e.g. with a temporary shared folder or mounted ISO.
4. Run `sudo bash install.sh` (internet needed only for apt installation).
5. Run `sudo passwd student` to set the student password.
6. As teacher, test `su - student`, `cat ~/cases/MISSIONS.txt`, `curl http://127.0.0.1/`, `sqlite3 /opt/cyberlab/evidence/training.sqlite 'select * from notes;'`, `tcpdump -nn -A -r /opt/cyberlab/evidence/http.pcap`.
7. Save `/root/CYBERLAB-TEACHER-KEY.txt` securely **outside the VM**, then delete the key and `/root/cyberlab-seed.py` from the VM before distribution. Also remove the installer folder from the VM.
8. Shut down, disable network adapter in VirtualBox, export as `CYBERLAB-TJKT-V2-50FLAG.ova`. Import into a new VM and retest as student.

## Security and design notes

- The SQL injection and XSS examples are intentionally vulnerable, and must only be used on a disconnected lab VM. Apache binds to loopback (`127.0.0.1`). Never expose it to school/public networks.
- **Do not rerun** `seed.py` after distributing flags; it changes flags and invalidates the teacher key.
- Because students own the VM, no offline design can guarantee flags are impossible to extract or share. Require written explanations and screenshots as evidence.
- The prototype uses 50 generated flags, but several advanced flags are found by reading synthetic forensic artifacts. Expand these into multi-step challenges before high-stakes assessment.
- This package has not been end-to-end tested inside Ubuntu Server; validate on a disposable VM before classroom use.
